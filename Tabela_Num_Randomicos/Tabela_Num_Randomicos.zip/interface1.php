<html>
  <head>
    <title>INSERÇÃO BD</title>
    <meta charset="utf-8"/> 
  </head>
    
  <body> 
    <h1 style="color: white; background-color: FireBrick; text-align:center;">SIMULAÇÃO DE SORTEIO NATALINO</h1>
    
    <h3 style="color: black;">Atividade - Tabela de Números Randomicos</h3>
    <h3 style="color: FireBrick;">Autor: Marcos Daniel F. dos Santos</h3>
    <img src = "/imagens/sorteioNatal.jpg" width="510" height="250"><br>

    <p style="font-size:18px; color:FireBrick;"><b>Nessa atividade será simulado um sorteio!<br>
    Ao apertar o Botão Gerar, você irá gerar um bilhete com: o número do seu bilhete, a data de emissão e os 3 números que podem ser sorteados.<b></p>
    
    <form action="inserir1.php" method="GET">
      <label></label>
      <input type="submit" value="Gerar" name="submit"><br>
    </form>

    <a href = "consulta1.php">Consultar Bilhetes</a><br><br><br>
    <label>Link para baixar os aquivos:</label>
    <a href="/Tabela_Num_Randomicos/Tabela_Num_Randomicos.zip" download="Atividade_Números_Aleatórios">Download Atividade Números Aleatórios</a>
</body>

</html>